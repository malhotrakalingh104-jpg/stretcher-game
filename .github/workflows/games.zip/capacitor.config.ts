import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.apnaparivaar.stretcher',
  appName: 'Stretcher Chaos',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false
  },
  plugins: {
    // Google AdMob Configuration
    // Test Banner: ca-app-pub-3940256099942544/6300978111
    // Test Interstitial: ca-app-pub-3940256099942544/1033173712
    // Production Banner: ca-app-pub-9840841564629806/8142036230
    // Production Interstitial: ca-app-pub-9840841564629806/9988550473
  }
};

export default config;

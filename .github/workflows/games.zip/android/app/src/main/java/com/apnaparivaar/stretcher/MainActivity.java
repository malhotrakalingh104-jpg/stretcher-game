package com.apnaparivaar.stretcher;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

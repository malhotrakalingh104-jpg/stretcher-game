import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const zip = new JSZip();

function addDirectoryToZip(dirPath, zipFolder) {
  const items = fs.readdirSync(dirPath);
  for (const item of items) {
    if (item === '.gradle' || item === 'build') continue;
    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      const subFolder = zipFolder.folder(item);
      addDirectoryToZip(fullPath, subFolder);
    } else {
      const content = fs.readFileSync(fullPath);
      zipFolder.file(item, content);
    }
  }
}

async function createZip() {
  const androidDir = path.resolve('android');
  if (!fs.existsSync(androidDir)) {
    console.error('Android directory does not exist');
    process.exit(1);
  }

  const rootFolder = zip.folder('android');
  addDirectoryToZip(androidDir, rootFolder);

  const publicDir = path.resolve('public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  const outputPath = path.join(publicDir, 'stretcher-android-project.zip');
  console.log('Generating ZIP file...');
  const content = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 9 } });
  fs.writeFileSync(outputPath, content);
  console.log(`Saved Android project ZIP to ${outputPath} (${(content.length / 1024 / 1024).toFixed(2)} MB)`);

  const distDir = path.resolve('dist');
  if (fs.existsSync(distDir)) {
    const distOutputPath = path.join(distDir, 'stretcher-android-project.zip');
    fs.writeFileSync(distOutputPath, content);
    console.log(`Also copied ZIP to ${distOutputPath}`);
  }
}

createZip().catch(console.error);
